package com.company;

public class InsertionSort {

    public static Integer[] arrayToSort = new Integer[]{1, 4, 6, 34, 45, 25, 342, 244, 2};

    public static boolean less(Comparable thisValue, Comparable thatValue) {
        return thisValue.compareTo(thatValue) < 0;
    }

    public static void exchange(Comparable[] array, int indexFrom, int indexto) {
        Comparable temp = array[indexFrom];
        array[indexFrom] = array[indexto];
        array[indexto] = temp;

    }//Selection

    public static void printArray(Integer[] array) {
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i]);
            System.out.print(" ");
        }
        System.out.println("  End of array");
    }

    public static void main(String[] args) {
        var five = 5;
        var six = 6;
        System.out.println(less(5, 6));
        var arrayLength = arrayToSort.length;
        printArray(arrayToSort);
        for (int i = 1; i < arrayLength; i++) {
            int min = i;

            for (int internalindex = i; internalindex > 0 && less(arrayToSort[internalindex], arrayToSort[internalindex - 1]); internalindex--) {
                exchange(arrayToSort, internalindex, internalindex - 1);
            }
            printArray(arrayToSort);
        }


    }
}