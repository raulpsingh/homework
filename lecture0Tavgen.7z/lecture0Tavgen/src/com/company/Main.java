package com.company;

import com.company.mainor.LinkedListStack;
import com.company.mainor.ResizingArrayBag;
import com.company.mainor.ResizingArrayStack;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
    // var arrrayListExample = new ArrayList<String>();
     //var bag = new ResizingArrayBag<Integer>();
     //var linkedListBag = new LinkedListBag<Integer>();
        var stack = new LinkedListStack<Integer>();
     for(int i=0 ; i<10;i++){
         stack.push(i);
        // bag.add(i);
         //linkedListBag.add(i);
     }
	/*var bag=new ResizingArrayBag<String>();
    bag.add("One");
    bag.add("Two");
    bag.add("Three");
    bag.add("Four");
    bag.add("Five");*/

        //System.out.println("Size of bag " + stack.size()/*bag.size()*/ );
        int sum = 0;
        /*for(Integer element: linkedListBag){
            sum = sum +element;
        }*/
        for(int i =0 ; i<10 ; i++) {
            System.out.println(stack.pop());
        }
        //System.out.println("Sum of numbers " + sum);
        }

    }

