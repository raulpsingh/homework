package com.company.mainor;

public interface iterable<item> {
}
