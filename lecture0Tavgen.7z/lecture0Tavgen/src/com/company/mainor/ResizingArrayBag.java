package com.company.mainor;

import java.util.Iterator;

public class ResizingArrayBag<item> implements Iterable<item> {
    private item[] storage;
    private int amount = 0;

    public ResizingArrayBag(){
        storage = (item[])new Object[2];
    }

    public boolean isEmpty(){
        return amount ==0 ;
    }

    public int size(){
        return amount;
    }

    public void add(item item){
        if(amount == storage.length){
            resize(2*storage.length);
        }
        storage[amount++] = item;
       // amount = amount + 1;
    }

    private void resize(int capacity) {
        assert capacity >= amount;
        item[] temp = (item[]) new Object[capacity];
        for (int i = 0; i<amount; i++) {
            temp[i] = storage[i];
        }
        storage = temp;
    }

    @Override
    public Iterator<item> iterator() {
        return new ArrayIterator();
    }
    private class ArrayIterator implements Iterator<item> {
        private int counter = 0;

        @Override
        public boolean hasNext() {
            return counter<amount;
        }

        @Override
        public item next() {
            return storage[counter++];
        }

    }

}

