package com.company.mainor;

public interface iterator {
    iterator iterator();
}
