package com.company;

import org.w3c.dom.ls.LSOutput;

import java.util.Random;

public class test {
    public static int factorialRecursive(int number) {
        if (number == 1) {
            return 1;
        }
        else {
            return  number * factorialRecursive(number-1);
        }
    }
    public static int factorialCycle(int number){
        int result = 1;
        for (int i=1; i<=number; i++){
            result = result * i;
        }
        return result;
    }
    public static Integer[] arrayToSort = new Integer[] {1,4,6,34,45,25,342,244,2};

    public static boolean less(Comparable thisValue, Comparable thatValue) {
        return thisValue.compareTo(thatValue) < 0;
    }
    public static void exchange(Comparable[] array, int indexFrom, int indexto){
        Comparable temp = array[indexFrom];
        array[indexFrom] = array[indexto];
        array[indexto] = temp;

    }//Selection
    public static void printArray(Integer[] array){
        for(int i=0; i<array.length; i++){
            System.out.print(array[i]);
            System.out.print(" ");
        }
        System.out.println("  End of array");
    }
    public static void main(String[] args) {
        var statistics = new Statistics();
        var random = new Random();
        for (int i = 0; i < 10000; i++){
            statistics.add(random.nextInt());
        }
       /* System.out.println("Maximal value - " + statistics.getMax());
        System.out.println("Minimal value - " + statistics.getMin());
        System.out.println("Average value - " + statistics.getAvg());*/
        System.out.println(factorialRecursive(10));
        System.out.println(factorialCycle(10));
        var five = 5;
        var six = 6;
        System.out.println(less(5,6));
        var arrayLength = arrayToSort.length;
        printArray(arrayToSort);
        for(int i=0; i<arrayLength; i++){
            int min = i;

           for(int internalIndex = i + 1; internalIndex < arrayLength; internalIndex++) {
               if (less(arrayToSort[internalIndex], arrayToSort[min])) {
                   min = internalIndex;
               }
           }
                   exchange(arrayToSort, i, min);

    }
        printArray(arrayToSort);
    }
}
